"""
Project AIVT 虛擬主播系統 - 本地客戶端
運行於 Mac Mini 4 Pro，負責音訊輸入輸出與雲端連接
"""

import asyncio
import json
import os
import sys
import base64
import logging
import argparse
import uuid
from datetime import datetime
from typing import Optional

import pyaudio
import numpy as np
import websockets
from dotenv import load_dotenv

# 載入環境變數
load_dotenv()

# 設定日誌
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


# ==================== 配置 ====================

class Config:
    """客戶端配置"""

    # 伺服器設定
    server_url: str = os.getenv("SERVER_URL", "ws://localhost:8000")
    client_id: str = os.getenv("CLIENT_ID", f"client-{uuid.uuid4().hex[:8]}")

    # 音訊設定
    sample_rate: int = int(os.getenv("AUDIO_SAMPLE_RATE", "16000"))
    channels: int = int(os.getenv("AUDIO_CHANNELS", "1"))
    chunk_size: int = int(os.getenv("AUDIO_CHUNK_SIZE", "1024"))
    audio_format = pyaudio.paInt16

    # 虛擬音訊線路
    loopback_device: str = os.getenv("AUDIO_LOOPBACK_DEVICE", "BlackHole 2ch")

    # 調試
    debug: bool = os.getenv("DEBUG", "true").lower() == "true"


config = Config()


# ==================== 音訊管理器 ====================

class AudioManager:
    """音訊管理器，負責音訊輸入輸出"""

    def __init__(self):
        self.audio = pyaudio.PyAudio()
        self.input_stream: Optional[pyaudio.Stream] = None
        self.output_stream: Optional[pyaudio.Stream] = None
        self.is_recording = False

    def list_devices(self):
        """列出所有音訊設備"""
        logger.info("可用的音訊設備：")
        for i in range(self.audio.get_device_count()):
            device_info = self.audio.get_device_info_by_index(i)
            logger.info(f"  [{i}] {device_info['name']}")

    def get_input_device_index(self, device_name: str = None) -> int:
        """取得輸入設備索引"""
        device_name = device_name or config.loopback_device

        for i in range(self.audio.get_device_count()):
            device_info = self.audio.get_device_info_by_index(i)
            if device_name.lower() in device_info['name'].lower():
                return i

        # 回退到預設設備
        logger.warning(f"找不到設備 '{device_name}'，使用預設輸入設備")
        return self.audio.get_default_input_device_info()['index']

    def get_output_device_index(self, device_name: str = None) -> int:
        """取得輸出設備索引"""
        device_name = device_name or config.loopback_device

        for i in range(self.audio.get_device_count()):
            device_info = self.audio.get_device_info_by_index(i)
            if device_name.lower() in device_info['name'].lower():
                return i

        # 回退到預設設備
        logger.warning(f"找不到設備 '{device_name}'，使用預設輸出設備")
        return self.audio.get_default_output_device_info()['index']

    def start_input_stream(self, callback):
        """開始輸入音訊串流"""
        try:
            device_index = self.get_input_device_index()

            self.input_stream = self.audio.open(
                format=config.audio_format,
                channels=config.channels,
                rate=config.sample_rate,
                input=True,
                input_device_index=device_index,
                frames_per_buffer=config.chunk_size,
                stream_callback=callback
            )

            self.is_recording = True
            logger.info(f"開始錄音，使用設備: {self.audio.get_device_info_by_index(device_index)['name']}")

        except Exception as e:
            logger.error(f"啟動輸入串流失敗: {str(e)}")
            raise

    def start_output_stream(self):
        """開始輸出音訊串流"""
        try:
            device_index = self.get_output_device_index()

            self.output_stream = self.audio.open(
                format=config.audio_format,
                channels=config.channels,
                rate=config.sample_rate,
                output=True,
                output_device_index=device_index
            )

            logger.info(f"開始播放，使用設備: {self.audio.get_device_info_by_index(device_index)['name']}")

        except Exception as e:
            logger.error(f"啟動輸出串流失敗: {str(e)}")
            raise

    def write_audio(self, audio_data: bytes):
        """播放音訊"""
        if self.output_stream:
            try:
                self.output_stream.write(audio_data)
            except Exception as e:
                logger.error(f"播放音訊失敗: {str(e)}")

    def stop(self):
        """停止所有串流"""
        if self.input_stream:
            self.input_stream.stop_stream()
            self.input_stream.close()
            self.input_stream = None

        if self.output_stream:
            self.output_stream.stop_stream()
            self.output_stream.close()
            self.output_stream = None

        self.is_recording = False
        logger.info("音訊串流已停止")

    def terminate(self):
        """終止 PyAudio"""
        self.stop()
        self.audio.terminate()


# ==================== 客戶端 ====================

class AIVTClient:
    """AIVT 客戶端主類別"""

    def __init__(self):
        self.ws: Optional[websockets.WebSocketClientProtocol] = None
        self.audio_manager = AudioManager()
        self.is_connected = False
        self.is_speaking = False
        self.receive_task: Optional[asyncio.Task] = None

    async def connect(self):
        """連接到雲端伺服器"""
        try:
            url = f"{config.server_url}/ws/{config.client_id}"
            logger.info(f"連接到: {url}")

            self.ws = await websockets.connect(
                url,
                ping_interval=30,
                ping_timeout=10
            )

            self.is_connected = True
            logger.info("已連接到伺服器")

            # 啟動接收任務
            self.receive_task = asyncio.create_task(self.receive_messages())

        except Exception as e:
            logger.error(f"連接失敗: {str(e)}")
            self.is_connected = False
            raise

    async def disconnect(self):
        """斷開連接"""
        self.is_connected = False

        if self.receive_task:
            self.receive_task.cancel()
            try:
                await self.receive_task
            except asyncio.CancelledError:
                pass

        if self.ws:
            await self.ws.close()

        logger.info("已斷開連接")

    async def send_message(self, message: dict):
        """發送訊息到伺服器"""
        if self.ws and self.is_connected:
            try:
                await self.ws.send(json.dumps(message))
            except Exception as e:
                logger.error(f"發送訊息失敗: {str(e)}")

    async def send_text(self, text: str):
        """發送文字訊息"""
        await self.send_message({
            "type": "text",
            "content": text
        })

    async def send_audio(self, audio_data: bytes):
        """發送音訊資料"""
        audio_b64 = base64.b64encode(audio_data).decode("utf-8")
        await self.send_message({
            "type": "audio",
            "data": audio_b64
        })

    async def send_interrupt(self):
        """發送中斷訊號"""
        await self.send_message({
            "type": "interrupt"
        })

    async def receive_messages(self):
        """接收伺服器訊息"""
        try:
            async for message in self.ws:
                try:
                    data = json.loads(message)
                    await self.handle_message(data)
                except json.JSONDecodeError:
                    logger.warning(f"收到無效的 JSON: {message[:100]}")

        except websockets.exceptions.ConnectionClosed:
            logger.info("伺服器連接已關閉")
        except Exception as e:
            logger.error(f"接收訊息錯誤: {str(e)}")

    async def handle_message(self, data: dict):
        """處理收到的訊息"""
        msg_type = data.get("type", "")
        content = data.get("content", "")

        if msg_type == "system":
            logger.info(f"系統: {content}")

        elif msg_type == "echo":
            logger.info(f"回顯: {content}")

        elif msg_type == "text":
            logger.info(f"AI: {content}")
            print(f"\n🤖 AI: {content}\n> ", end="")

        elif msg_type == "text_chunk":
            # 串流文字片段
            print(content, end="", flush=True)

        elif msg_type == "response_complete":
            # 回應完成
            print()  # 換行
            logger.info("AI 回應完成")

        elif msg_type == "audio":
            # 收到音訊
            audio_b64 = data.get("data", "")
            if audio_b64:
                audio_data = base64.b64decode(audio_b64)
                self.audio_manager.write_audio(audio_data)
                self.is_speaking = True

        elif msg_type == "interrupt_ack":
            # 中斷確認
            self.is_speaking = False
            logger.info("已中斷 AI 說話")

        elif msg_type == "error":
            logger.error(f"錯誤: {content}")

        else:
            logger.debug(f"未知訊息類型: {msg_type}")

    def audio_callback(self, in_data, frame_count, time_info, status):
        """音訊輸入回調函數"""
        if status:
            logger.warning(f"音訊輸入狀態: {status}")

        # 發送音訊到伺服器
        if self.is_connected and self.ws:
            try:
                # 異步發送（需要在事件迴圈中）
                asyncio.create_task(self.send_audio(in_data))
            except Exception as e:
                logger.error(f"發送音訊失敗: {str(e)}")

        return (in_data, pyaudio.paContinue)

    async def start_audio(self):
        """啟動音訊輸入輸出"""
        # 啟動輸入串流（麥克風）
        self.audio_manager.start_input_stream(self.audio_callback)

        # 啟動輸出串流（喇叭）
        self.audio_manager.start_output_stream()

    async def run(self):
        """執行客戶端"""
        logger.info("=" * 50)
        logger.info("Project AIVT 客戶端啟動")
        logger.info("=" * 50)

        # 列出可用設備
        self.audio_manager.list_devices()

        try:
            # 連接到伺服器
            await self.connect()

            # 啟動音訊
            await self.start_audio()

            # 顯示說明
            print("\n" + "=" * 50)
            print("🤖 AIVT 虛擬主播客戶端")
            print("=" * 50)
            print("輸入文字訊息與 AI 對話")
            print("說話將通過麥克風傳輸到雲端")
            print("輸入 'quit' 或 'exit' 退出")
            print("輸入 'interrupt' 或 '打斷' 中斷 AI 說話")
            print("=" * 50 + "\n")

            # 文字輸入迴圈
            while self.is_connected:
                try:
                    user_input = await asyncio.get_event_loop().run_in_executor(
                        None,
                        lambda: input("> ")
                    )

                    if user_input.lower() in ["quit", "exit", "q"]:
                        break

                    if user_input.lower() in ["interrupt", "打斷", "stop"]:
                        await self.send_interrupt()
                        continue

                    if user_input.strip():
                        await self.send_text(user_input)

                except EOFError:
                    break
                except Exception as e:
                    logger.error(f"輸入錯誤: {str(e)}")

        except KeyboardInterrupt:
            logger.info("收到 Ctrl+C")

        except Exception as e:
            logger.error(f"執行錯誤: {str(e)}")

        finally:
            await self.disconnect()
            self.audio_manager.terminate()
            logger.info("客戶端已關閉")


# ==================== 主程式 ====================

def main():
    """主函數"""
    parser = argparse.ArgumentParser(description="AIVT 虛擬主播客戶端")
    parser.add_argument("--server", "-s", help="伺服器 URL")
    parser.add_argument("--debug", "-d", action="store_true", help="啟用調試模式")

    args = parser.parse_args()

    if args.server:
        config.server_url = args.server

    if args.debug:
        config.debug = True
        logging.getLogger().setLevel(logging.DEBUG)

    # 執行客戶端
    client = AIVTClient()
    asyncio.run(client.run())


if __name__ == "__main__":
    main()
