# Project AIVT - 虛擬主播系統

一個專業級的虛擬主播直播系統，支援即時語音互動與嘴型驅動。

## 系統架構

```
┌─────────────────────────────────────────────────────────────┐
│                     本地端 (Mac Mini)                        │
│  ┌──────────┐    ┌──────────┐    ┌──────────────────────┐ │
│  │  麥克風   │───>│ 客戶端   │───>│  VTube Studio        │ │
│  └──────────┘    └──────────┘    │  (嘴型驅動/渲染)      │ │
│                                    └──────────────────────┘ │
│  ┌──────────┐         ┌──────────┐                        │
│  │  喇叭    │<────────│ 客戶端   │                        │
│  └──────────┘         └──────────┘                        │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ WebSocket
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     雲端伺服器 (GPU)                         │
│  ┌──────────┐    ┌──────────┐    ┌──────────────────────┐ │
│  │ DeepSeek │<───│ WebSocket│<───│  Deepgram            │ │
│  │  (對話)  │    │ Server   │    │  (語音識別)          │ │
│  └──────────┘    └──────────┘    └──────────────────────┘ │
│                           │                                  │
│                           ▼                                  │
│                    ┌──────────────────┐                     │
│                    │  GPT-SoVITS      │                     │
│                    │  (語音合成)       │                     │
│                    └──────────────────┘                     │
└─────────────────────────────────────────────────────────────┘
```

## 快速開始

### 1. 配置雲端伺服器

```bash
# 進入雲端後端目錄
cd cloud_backend

# 複製環境變數範本
cp .env.example .env

# 編輯 .env 填入 API Keys
nano .env
```

### 2. 本地測試（不需要 GPU）

```bash
# 安裝依賴
pip install -r cloud_backend/requirements.txt

# 啟動伺服器
cd cloud_backend
python main.py
```

### 3. 部署到雲端

參考 `docs/DEPLOYMENT.md` 文件進行雲端部署。

### 4. 配置本地客戶端

```bash
# 進入客戶端目錄
cd local_client

# 複製環境變數範本
cp .env.example .env

# 編輯 .env，設定伺服器 URL
nano .env

# 安裝依賴
pip install -r requirements.txt

# 執行客戶端
python client.py
```

## 專案結構

```
project-aivt/
├── SPEC.md                    # 詳細技術規格
├── cloud_backend/            # 雲端後端
│   ├── app/
│   │   ├── __init__.py
│   │   ├── config.py         # 配置管理
│   │   ├── deepseek_client.py
│   │   ├── deepgram_client.py
│   │   ├── tts_client.py
│   │   └── connection_manager.py
│   ├── main.py               # FastAPI 主應用
│   ├── requirements.txt
│   ├── Dockerfile
│   └── docker-compose.yml
├── local_client/              # 本地客戶端
│   ├── client.py              # Python 客戶端
│   └── requirements.txt
└── docs/
    └── DEPLOYMENT.md          # 部署指南
```

## 功能特性

- ✅ 即時語音對話（WebSocket）
- ✅ DeepSeek API 整合
- ✅ Deepgram 語音識別
- ✅ GPT-SoVITS 語音合成（可選）
- ✅ VTube Studio 嘴型驅動
- ✅ OBS 直播推流整合

## 技術規格

- **延遲**: < 1.5 秒（端到端）
- **語音識別**: Deepgram Nova-2
- **對話模型**: DeepSeek-V3
- **語音合成**: GPT-SoVITS
- **客戶端**: macOS + VTube Studio
- **雲端**: RunPod/Lambda Labs (RTX 3090+)

## 成本預估

| 服務 | 費用/月 |
|------|---------|
| DeepSeek API | $20-50 |
| Deepgram | $30 |
| GPU 伺服器 | $80-100 |
| **總計** | **$130-180** |

## 支援

如有問題，請參考：
- SPEC.md - 詳細技術規格
- docs/DEPLOYMENT.md - 部署指南
