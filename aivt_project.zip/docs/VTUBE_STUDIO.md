# VTube Studio 整合指南

本指南說明如何將 VTube Studio 與 Project AIVT 系統整合，實現虛擬人物的嘴型驅動。

## 前置要求

### 軟體需求

1. **VTube Studio** (v1.25.0+)
   - 從 Steam 或官方網站購買下載
   - 價格：約 $30 (含基本功能)

2. **虛擬音訊線路** (二選一)
   - **BlackHole** (免費) - 推薦
     - 下載：https://github.com/ExistentialAudio/BlackHole
     - 需要安裝 2ch 版本
   - **Loopback** (付費 $99)
     - 下載：https://rogueamoeba.com/loopback/

3. **OBS Studio** (可選)
   - 用於直播推流
   - 下載：https://obsproject.com

## 安裝步驟

### 1. 安裝 BlackHole

```bash
# 使用 Homebrew 安裝
brew install --cask blackhole-2ch

# 或者從官網下載 PKG 檔案手動安裝
```

安裝完成後，在系統偏好設定 > 聲音 > 輸入/輸出 中可以看到 "BlackHole 2ch" 選項。

### 2. 配置 BlackHole

#### 建立多輸出設備（可選）

若需要同時播放聲音到喇叭和 BlackHole：

1. 打開「音訊 MIDI 設定」
2. 按「+」建立「多輸出裝置」
3. 勾選：
   - 內建輸出
   - BlackHole 2ch

### 3. 配置 VTube Studio

1. 啟動 VTube Studio
2. 進入設定 (Settings)
3. 找到「Audio Input」或「嘴型驅動」設定
4. 選擇輸入設備為「BlackHole 2ch」

#### 嘴型驅動參數調整

根據 VTube Studio 版本，可能需要調整以下參數：

```
Audio Input Source: BlackHole 2ch
Lip Sync Mode: Audio-Based
Sensitivity: 50-70 (根據實際效果調整)
Smoothing: 30-50
```

### 4. 配置本地客戶端

編輯 `local_client/.env`：

```env
AUDIO_LOOPBACK_DEVICE=BlackHole 2ch
```

## 測試嘴型驅動

### 測試流程

1. **啟動 VTube Studio**
   - 載入喜歡的 Live2D 模型
   - 確認嘴型跟隨麥克風輸入移動

2. **啟動 AIVT 客戶端**
   - 連接到雲端伺服器
   - 確保輸出設備設定為 BlackHole

3. **測試語音互動**
   - 對著麥克風說話
   - 觀察 VTube Studio 中模型的嘴型

### 驗收標準

| 項目 | 標準 |
|------|------|
| 嘴巴開合 | 說話時嘴巴會打開，靜止時閉合 |
| 同步延遲 | 嘴型延遲 < 200ms |
| 自然度 | 無明顯的嘴型抽搐或延遲 |

## 常見問題

### Q: VTube Studio 收不到 BlackHole 的聲音

**解決方案**：
1. 確認系統偏好設定中 BlackHole 設為輸入設備
2. 確認 VTube Studio 的音訊輸入來源設為 BlackHole
3. 檢查其他應用程式是否正在使用 BlackHole

### Q: 嘴型不夠明顯

**解決方案**：
1. 增加 Sensitivity 參數
2. 調低 Threshold 參數
3. 確認 Live2D 模型有正確的嘴型參數

### Q: 聲音和嘴型不同步

**解決方案**：
1. 檢查音訊延遲設定
2. 調整 VTube Studio 的 Audio Delay 參數
3. 確認網路延遲穩定

### Q: 如何同時聽到聲音和驅動嘴型

**解決方案**：
使用多輸出設備：
1. 建立多輸出裝置（內建輸出 + BlackHole）
2. 客戶端輸出設為多輸出裝置
3. VTube Studio 輸入設為 BlackHole

## 進階設定

### 使用參數控制嘴型

對於 3D VRM 模型，可以使用 OSC 控制：

```python
# 範例：OSC 訊息
/VTS/param/MouthOpen 0.5  # 嘴巴開合程度 0-1
/VTS/param/MouthSmile 0.3 # 微笑程度 0-1
```

### 聲音處理

可選：在客戶端加入音訊處理提升品質

```python
# 範例：音訊正規化
import numpy as np

def normalize_audio(audio_data):
    audio = np.frombuffer(audio_data, dtype=np.int16)
    audio = audio.astype(np.float32) / 32768.0
    audio = audio / np.max(np.abs(audio)) * 0.9  # 正規化
    return (audio * 32768).astype(np.int16).tobytes()
```

## 模型建議

### 推薦的 Live2D 模型

1. **Victoria Minehart**
   - 風格：寫實
   - 特點：高品質，適合專業直播

2. **Cyber#ika**
   - 風格：Cyberpunk
   - 特點：動態效果豐富

3. **Kizuna AI 風格模型**
   - 風格：動漫
   - 特點：活潑可愛

### 取得模型

- **Steam Workshop**: 大量免費/付費模型
- **Booth.pm**: 日本創作市場
- **Vroid Hub**: VRM 格式模型

## 替代方案

如果無法使用 VTube Studio，可以考慮：

### Unity/Unreal Engine

1. 使用 Unity + VRM4U 插件
2. 導入 VRM 模型
3. 使用 uLipSync 實現嘴型同步
4. 通過 OBS 擷取

### 開源替代方案

- **Luppet**: 免費的虛擬形象軟體
- **Animaze**: 支援多種平台的虛擬形象

---

如需更多幫助，請參考：
- VTube Studio 官方文檔
- BlackHole GitHub 頁面
- Project AIVT SPEC.md
