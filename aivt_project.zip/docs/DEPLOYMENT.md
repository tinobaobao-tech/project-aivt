# Project AIVT 雲端部署腳本

## 前置要求

1. Docker Desktop 安裝完成
2. DeepSeek API Key
3. Deepgram API Key

## 快速部署

### 1. 配置環境變數

```bash
cd cloud_backend
cp .env.example .env
```

編輯 `.env` 檔案，填入您的 API Keys：

```
DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
DEEPGRAM_API_KEY=your-deepgram-api-key
```

### 2. 建構 Docker 映像

```bash
docker build -t aivt-backend:latest .
```

### 3. 執行容器

```bash
# 基本執行
docker run -d \
  --name aivt-backend \
  -p 8000:8000 \
  --env-file cloud_backend/.env \
  aivt-backend:latest

# 查看日誌
docker logs -f aivt-backend

# 停止容器
docker stop aivt-backend
```

### 4. 使用 Docker Compose（推薦）

```bash
docker-compose up -d
docker-compose logs -f
docker-compose down
```

## 部署到 RunPod

### 1. 建立 RunPod 帳號

訪問 https://runpod.io 註冊帳號

### 2. 建立 GPU 實例

選擇以下配置：
- GPU: RTX 3090 或 RTX 4090
- CPU: 8 vCPU
- RAM: 32 GB
- 磁碟: 50 GB
- 環境: PyTorch 2.1 + CUDA 12.1

### 3. 部署應用

```bash
# SSH 到 RunPod 伺服器
ssh root@<your-runpod-ip>

# 安裝 Docker
apt-get update && apt-get install -y docker.io docker-compose

# 複製專案
git clone <your-repo-url>
cd aivt

# 配置環境變數
cp cloud_backend/.env.example cloud_backend/.env
nano cloud_backend/.env  # 填入 API Keys

# 啟動服務
cd cloud_backend
docker-compose up -d
```

### 4. 設定安全群組

確保以下連接埠開放：
- 8000: WebSocket 伺服器
- 5001: GPT-SoVITS（可選）

## 部署到 Lambda Labs

### 1. 建立實例

訪問 https://lambdalabs.com 租用 GPU 實例

### 2. 部署步驟

類似 RunPod 的部署流程

## 測試部署

### 測試健康檢查

```bash
curl http://localhost:8000/health
```

預期回應：
```json
{
  "status": "healthy",
  "timestamp": "2026-02-26T...",
  "connections": 0
}
```

### 測試 WebSocket

使用 WebSocket 客戶端工具（如 wscat）：

```bash
npm install -g wscat
wscat -c ws://localhost:8000/ws/test-client
```

### 測試 API

```bash
# 測試聊天 API
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "你好"}'
```

## 常見問題

### Q: 容器啟動失敗
A: 檢查日誌 `docker logs aivt-backend`，確認 .env 檔案存在且 API Keys 正確

### Q: WebSocket 連接失敗
A: 確認防火牆允許 8000 連接埠

### Q: 費用過高
A: 直播結束後記得關閉 GPU 實例，或使用 Spot Instance

## 自動化腳本

### 啟動腳本 (start.sh)

```bash
#!/bin/bash

echo "啟動 AIVT 後端服務..."

# 啟動容器
docker-compose up -d

# 等待服務就緒
sleep 5

# 檢查狀態
curl http://localhost:8000/health

echo "服務已啟動!"
```

### 停止腳本 (stop.sh)

```bash
#!/bin/bash

echo "停止 AIVT 後端服務..."
docker-compose down
echo "服務已停止"
```

## 監控

### 設定費用警報

在 RunPod/Lambda Labs 控制台設定：
- 每月費用上限警告（$150）
- 每日費用上限警告（$10）

### 日誌管理

```bash
# 查看即時日誌
docker-compose logs -f

# 保留最近 1000 行
docker-compose logs --tail=1000 > logs.txt
```
